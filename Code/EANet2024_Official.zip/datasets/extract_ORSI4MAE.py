import os
import sys
import json
import pickle
import random

import torch
from tqdm import tqdm

import matplotlib.pyplot as plt
import os
import shutil

random.seed(2023)

# D:\2023_Files\BAS_Dataset\LC8BAS512
# D:\2023_Files\BAS_Dataset\LC8BAS1K
SRC_IMG_PATH='D:/2023_Files/RS_SOD_Dataset/ORSI4199/Test/Images/'
TAR_IMG_PATH='D:/2023_Files/RS_SOD_Dataset/ORSI4MAE/Images/'

png_imgs=[i for i in os.listdir(SRC_IMG_PATH)]

sample_num=200
print('test_num:', sample_num)

test_list = random.sample(png_imgs, sample_num)


for img in tqdm(test_list):   
    src_img=SRC_IMG_PATH+img
    save_img=TAR_IMG_PATH+img

    shutil.copy(src_img, save_img)

